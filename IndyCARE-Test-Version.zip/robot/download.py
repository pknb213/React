import requests
import datetime
import json
import shutil
from test_config import URL, POST, GET

s = requests.Session()

res = s.post(URL+'/login', {'username': 'developer', 'password': '1234'})
print(res.text)


res = GET(s,'/get_robots', params={'customer': 'hello'})
robots = list(json.loads(res.text).keys())
robots.sort()
print('Robot SN List of hello:', robots)

#@app.route("/clips/<sn>/<cam>")
#@app.route("/get_event_data/<evid>")

res = s.get(URL+'/clips/' + robots[0], stream=True)
if res.status_code == 200 :
    with open ('dn_'+robots[0]+'.mov', 'wb') as f:
        shutil.copyfileobj(res.raw, f)
    print('CLIP DOWNLOADED')

res = GET(s,'/get_robot_history/'+ robots[0])
events = list(map(lambda x : x['_id'], json.loads(res.text)))
print('Events List:', events)
res = s.get(URL+'/get_event_data/' + events[0], stream=True)
if res.status_code == 200 :
    with open ('dn_'+events[0]+'.tgz', 'wb') as f:
        shutil.copyfileobj(res.raw, f)
    print('LOG DOWNLOADED')

res = s.get(URL+'/logout')
print(res.text)
