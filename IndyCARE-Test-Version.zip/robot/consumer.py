import requests
import datetime
import json
from test_config import URL, POST, GET

s = requests.Session()


res = s.post(URL+'/login', {'username': 'developer', 'password': '1234'})
print(res.text)


res = GET(s, '/get_customers')
customers = list(json.loads(res.text))

c_id = str(customers[0]['_id'])
res = GET(s,'/get_robots/%s' % c_id)
robots = list(json.loads(res.text))
robots.sort()
print('Robot SN List of hello:', robots)

GET(s,'/robotstatus/' + robots[0])
GET(s,'/robotstatus/' + ','.join(robots))
res = GET(s,'/opdata/items/' + robots[0])
GET(s,'/opdata/'+ robots[0])
GET(s,'/opdata/'+ robots[0], params={'key':'power'})
GET(s,'/opdata/'+ robots[0], params={'limit':1})
GET(s,'/opdata/'+ robots[0]+'/*/10s')
GET(s,'/opdata/'+ robots[0]+'/*/2019-03-16T06:18:38.547441128Z,2019-03-16T06:44:08.460821321Z')

GET(s,'/get_robot_history/'+robots[0], params={})

res = s.get(URL+'/logout')
print(res.text)
