import datetime, functools, json

URL = 'http://192.168.0.89:5000'
# URL = 'http://localhost:5000'
robot_sn = 'r1'


def check_timing(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        t0 = datetime.datetime.now()
        res = func(*args, **kwargs)
        #if res.text:
        #    print(json.loads(res.text))
        t1 = datetime.datetime.now()
        print(t1 - t0)
        return res
    return wrapper


@check_timing
def POST(s, url, **kwargs):
    return s.post(URL + url, **kwargs)


@check_timing
def GET(s, url, **args):
    return s.get(URL + url, **args)


@check_timing
def PUT(s, url, **kwargs):
    return s.put(URL + url, **kwargs)


@check_timing
def DELETE(s, url, **kwargs):
    return s.delete(URL + url, **kwargs)
