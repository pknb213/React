from multiprocessing import Process
import requests
import datetime
import json
from test_config import URL, POST, GET

def info(title):
    import os
    print(title)
    print('module name:', __name__)
    print('parent process:', os.getppid())
    print('process id:', os.getpid())


def clip_uploader():
    info('clip')
    print('Clip uploader')

    s = requests.Session()
    res = s.post(URL + '/login', {'username': 'r3', 'password': 'r3'})
    print(res.text)

    with open('test.mp4', 'rb') as f:
        res = POST(s, '/upload_blackbox_clip', files={'file': f})
    print(res.text)

    res = s.get(URL+'/logout')
    print(res.text)
    print('Clip END')

clip_uploader()
