from multiprocessing import Process
from sseclient import SSEClient
import requests
import datetime
import json
from test_config import URL, POST, GET

def info(title):
    import os
    print(title)
    print('module name:', __name__)
    print('parent process:', os.getppid())
    print('process id:', os.getpid())


def clip_uploader():
    info('clip')
    print('Clip uploader')

    s = requests.Session()
    res = s.post(URL + '/login', {'username': 'r3', 'password': 'r3'})
    print(res.text)

    messages = SSEClient(URL + '/stream?channel=clip')
    for msg in messages:
        print('clip msg', msg.data)
        with open('test.mov', 'rb') as f:
            res = POST(s, '/upload_blackbox_clip', files={'file': f})
        print(res.text)

    res = s.get(URL+'/logout')
    print(res.text)
    print('Clip END')

def log_uploader():
    info('log')
    print('Log uploader')
    s = requests.Session()
    res = s.post(URL + '/login', {'username': 'r3', 'password': 'r3'})
    print(res.text)

    messages = SSEClient(URL + '/stream?channel=log')
    for msg in messages:
        print('log msg', msg.data)
        data = json.loads(msg.data)
        with open('mylog.tgz', 'rb') as f:
            res = POST(s, '/upload_event_data', files={'file': f, 'evid':(data['message'],'')})
        print(res.text)

    res = s.get(URL+'/logout')
    print(res.text)
    print('Log END')


if __name__ == '__main__':
    p1 = Process(target=clip_uploader)
    p2 = Process(target=log_uploader)
    p1.start()
    p2.start()
    p1.join()
    p2.join()
    #clip_uploader()
    #log_uploader()