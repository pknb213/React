import sys
from posix_ipc import MessageQueue, SharedMemory
from os import read, write, lseek, SEEK_SET
from struct import pack, unpack

INDY_SHM_NAME	= "indySHM"
INDY_SHM_LEN 	= 0x1000000	#16MB		== 0x000000~0xFFFFFF (~16777216)
INDY_SHM_ROBOT_ADDR_CTRL_STATUS_STRUCT_DATA			= 0x063000
INDY_NAME_POSIX_MSG_QUEUE = '/mq_indygo'
INDY_SUPPORT_INDYGO_SHM_NAME = 'indyGoShm'
INDY_SUPPORT_INDYGO_SHM_LEN = 4096
INDY_SHM_MGR_OFFSET = 64

class ShmWrapper(object):
    def __init__(self, name, offset, size, flags = 0):
        self.shm = SharedMemory(name, flags=flags)
        self.offset = offset + INDY_SHM_MGR_OFFSET 
        self.size = size
        print("Shared Memory:", name, self.offset, size)

    def read(self):
        lseek(self.shm.fd, self.offset, SEEK_SET)
        return read(self.shm.fd, self.size)


class MessageCounter(ShmWrapper):
    @property
    def counter(self):
        return unpack('I', super().read())[0]

    def inc(self):
        cnt =  self.counter + 1
        lseek(self.shm.fd, self.offset, SEEK_SET)
        write(self.shm.fd, pack('I', cnt))
        #print('counter increased', cnt, self.counter)

    def set(self, cnt):
        lseek(self.shm.fd, self.offset, SEEK_SET)
        write(self.shm.fd, pack('I', cnt))
   


class RobotState(ShmWrapper):
    @property
    def ready(self):
        return super().read()[0]

    @property
    def emergency(self):
        return super().read()[1]

    @property
    def collision(self):
        return super().read()[2]

    @property
    def error(self):
        return super().read()[3]

    @property
    def busy(self):
        return super().read()[4]

    @property
    def movedone(self):
        return super().read()[5]

    @property
    def home(self):
        return super().read()[6]

    @property
    def zoro(self):
        return super().read()[7]

    @property
    def resetting(self):
        return super().read()[8]

#try:
indyshm = RobotState(INDY_SHM_NAME, INDY_SHM_ROBOT_ADDR_CTRL_STATUS_STRUCT_DATA, 9)
msgcounter = MessageCounter(INDY_SUPPORT_INDYGO_SHM_NAME, 0, 4)
mq = MessageQueue(INDY_NAME_POSIX_MSG_QUEUE)

#except:
#    print("Fail to initialize")
#    sys.exit(-1)

# flush
while mq.current_messages > 0:
    print('flush')
    mq.receive()

#msgcounter.set(0)

while True:
    #print(msgcounter.counter)
    msgcounter.inc()
    data, pri = mq.receive()
    mtype, len = unpack('ll', data[:8])
    msg = data[8:8+data[8:].index(0)].decode('utf-8')
    print(mtype, msg, msgcounter.counter)


