import requests
import datetime
import json
import sys
import time
from test_config import URL, POST, GET

s = requests.Session()


res = s.post(URL+'/login', {'username':'r1', 'password':'r1'})
print(res.text)


# @app.route('/report_robot_status', methods=["POST"])
# @app.route('/report_robot_opdata', methods=["POST"])
# @app.route('/report_robot_event', methods=["POST"])
# @app.route('/upload_event_data', methods=["POST"])
# @app.route('/upload_blackbox_clip', methods=["POST"])

# todo : sys.argv : 명령행으로 프로그램 인자 값 받기
# todo : sys.argv[0]에는 기본적으로 python 실행파일의 경로가 담겨있음 (최소 길이 1)
# todo : ex) >> python d:\argsTest arg1 arg2
# todo : ex) >> sys.argv 길이 : 3
# todo : ex) >> arg value = d:\argsTest
# todo : ex) >> arg value = arg1
# todo : ex) >> arg value = arg2
sys.argv.append('o')
print(sys.argv)

loop_flag = True
if loop_flag:
    for i in range(0, 100):
        time.sleep(0.3)
        if len(sys.argv) == 1:
            print('Usage:%s s|o|e' % sys.argv[0])
        elif sys.argv[1] == 's':
            POST(s, '/report_robot_status', json=json.dumps({'state': 1, 'health': 'good', 'ready': 1}))
        elif sys.argv[1] == 'o':
            POST(s, '/report_robot_opdata', json={'kpi0': 1, 'kpi1': 2})
        elif sys.argv[1] == 'e':
            POST(s, '/report_robot_event', json={'time': str(datetime.datetime.now()), 'code': 0, 'log': 'test'})
        else:
            print('Unknown argument. \nUsage:%s s|o|e' % sys.argv[0])
else:
    if len(sys.argv) == 1:
        print('Usage:%s s|o|e' % sys.argv[0])
    elif sys.argv[1] == 's':
        POST(s, '/report_robot_status', json=json.dumps({'state': 1, 'health': 'good', 'ready': 1}))
    elif sys.argv[1] == 'o':
        POST(s, '/report_robot_opdata', json={'kpi0': 1, 'kpi1': 2})
    elif sys.argv[1] == 'e':
        POST(s, '/report_robot_event', json={'time': str(datetime.datetime.now()), 'code': 0, 'log': 'test'})
    else:
        print('Unknown argument. \nUsage:%s s|o|e' % sys.argv[0])

res = s.get(URL+'/logout')

