import sys
from posix_ipc import MessageQueue, SharedMemory, O_CREAT
from os import read, write, lseek, SEEK_SET
from struct import pack, unpack, calcsize
from multiprocessing import Process, Queue
from sseclient import SSEClient
import requests, datetime, json, time, functools
import os, glob, json, time, signal, zipfile

''' 2019-07-24'''
''' sse client 설치 필요 : sudo pip3 install --ignore-installed sseclient'''
''' posix_ipc 설치 필요 : 리눅스 전용 라이브러리, 사전에 최신 apt-get install python-dev 필요, pip install posix_ipc'''

INDY_SHM_NAME = "indySHM"
INDY_SHM_LEN = 0x1000000  # 16MB		== 0x000000~0xFFFFFF (~16777216)
INDY_SHM_ROBOT_ADDR_CTRL_STATUS_STRUCT_DATA = 0x063000
# ready, emergency, collision, error, busy, home
INDY_SHM_ROBOT_ADDR_STATE_STRUCT_DATA = 0x062000
# bool isContyConnected, bool isSCMConnected, char programState ( 0:stop, 1: run, 2: ime st)
INDY_SHM_ROBOT_ADDR_ERROR_CODE = 0x061000
# int type 0 ~ 14
INDY_SHM_ROBOT_ADDR_SCM_STATE_STRUCT_DATA = 0x068000  # SCMStateData (0x068000: isReporterRuning, ~1: isServerConnected)

INDY_SUPPORT_INDYGO_SHM_LEN = 4096
INDY_SHM_MGR_OFFSET = 64
INDY_NAME_POSIX_MSG_QUEUE = '/mq_indyCARE'
INDY_SUPPORT_INDYGO_SHM_NAME = 'indyCAREShm'
INDY_REPORTER_SHM_NAME = 'reporterShm'

BLACKBOX_CLIP_CHECK_TIMEOUT = 5

URL = 'http://192.168.0.89:5000'
# URL = 'http://172.23.254.121:8002'
robot_sn = 'D11929I07003'


def check_timing(func):
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        t0 = datetime.datetime.now()
        res = func(*args, **kwargs)
        #if res.text:
        #    print(json.loads(res.text))
        t1 = datetime.datetime.now()
        print(t0, t1 - t0)
        return res
    return wrapper


@check_timing
def POST(s, url, **kwargs):
    return s.post(URL + url, **kwargs)


@check_timing
def GET(s, url, **args):
    return s.get(URL + url, **args)


@check_timing
def PUT(s, url, **kwargs):
    return s.put(URL + url, **kwargs)


@check_timing
def DELETE(s, url, **kwargs):
    return s.delete(URL + url, **kwargs)


class ShmWrapper(object):
    def __init__(self, name, offset, size, flags=0):
        self.shm = SharedMemory(name, flags=flags)
        self.offset = offset + INDY_SHM_MGR_OFFSET
        self.size = size
        # print("Shared Memory:", name, self.offset, size)

    def read(self):
        lseek(self.shm.fd, self.offset, SEEK_SET)
        return read(self.shm.fd, self.size)

    def write(self):
        lseek(self.shm.fd, self.offset, SEEK_SET)
        return write(self.shm.fd, self.size)


class ShmSecondWrapper(object):
    def __init__(self, name, offset, size, flags=O_CREAT):
        self.shm = SharedMemory(name, flags=flags)
        self.offset = offset + INDY_SHM_MGR_OFFSET
        self.size = size
        print("Shared Memory (O_CREAT):", name, self.offset, size)
        lseek(self.shm.fd, self.offset, SEEK_SET)
        write(self.shm.fd, pack('b', 0))
        lseek(self.shm.fd, self.offset + 1, SEEK_SET)
        write(self.shm.fd, pack('b', 0))
        lseek(self.shm.fd, self.offset + 2, SEEK_SET)
        write(self.shm.fd, pack('b', 0))
        lseek(self.shm.fd, self.offset + 3, SEEK_SET)
        write(self.shm.fd, pack('b', 0))

    def read(self):
        lseek(self.shm.fd, self.offset, SEEK_SET)
        return read(self.shm.fd, self.size)

    def write(self):
        lseek(self.shm.fd, self.offset, SEEK_SET)
        return write(self.shm.fd, self.size)


class MessageCounter(ShmWrapper):
    @property
    def counter(self):
        return unpack('I', super().read())[0]

    def inc(self):
        cnt = self.counter + 1
        lseek(self.shm.fd, self.offset, SEEK_SET)
        write(self.shm.fd, pack('I', cnt))
        # print('counter increased', cnt, self.counter)

    def set(self, cnt):
        lseek(self.shm.fd, self.offset, SEEK_SET)
        write(self.shm.fd, pack('I', cnt))


class ScmStateData(ShmWrapper):
    def __del__(self):
        lseek(self.shm.fd, self.offset, SEEK_SET)
        write(self.shm.fd, pack('b', 0))
        lseek(self.shm.fd, self.offset + 1, SEEK_SET)
        write(self.shm.fd, pack('b', 0))

    @property
    def isReporterRunning(self):
        return super().read()[0]

    @property
    def isServerConnected(self):
        return super().read()[1]

    @staticmethod
    def turnOnReporter(indyshm):
        lseek(indyshm.shm.fd, indyshm.offset, SEEK_SET)
        return write(indyshm.shm.fd, pack('b', 1))

    @staticmethod
    def turnOnServer(indyshm):
        lseek(indyshm.shm.fd, indyshm.offset + 1, SEEK_SET)
        return write(indyshm.shm.fd, pack('b', 1))

    @staticmethod
    def turnOffReporter(indyshm):
        lseek(indyshm.shm.fd, indyshm.offset, SEEK_SET)
        return write(indyshm.shm.fd, pack('b', 0))

    @staticmethod
    def turnOffServer(indyshm):
        lseek(indyshm.shm.fd, indyshm.offset + 1, SEEK_SET)
        return write(indyshm.shm.fd, pack('b', 0))

    @staticmethod
    def getAllSCMState(indyshm):
        keys = ['isReporterRunning', 'isServerConnected']
        st = {}
        for key in keys: st[key] = getattr(indyshm, key)
        return st


class ErrorCode(ShmWrapper):
    @property
    def error_code(self):
        return unpack('i', super().read())[0]

    @staticmethod
    def get_all_error(indyshm):
        keys = ['error_code']
        st = {}
        for key in keys: st[key] = getattr(indyshm, key)
        return st


class RobotState(ShmWrapper):
    @property
    def is_task_running(self):
        return super().read()[0]

    @property
    def conty_connected(self):
        return super().read()[2]

    @property
    def scm_connected(self):
        return super().read()[4]

    @property
    def program_state(self):
        return super().read()[8]

    @staticmethod
    def get_all_state(indyshm):
        keys = ['is_task_running', 'conty_connected', 'scm_connected', 'program_state']
        st = {}
        for key in keys: st[key] = getattr(indyshm, key)
        return st


class ControlState(ShmWrapper):
    @property
    def ready(self):
        return super().read()[0]

    @property
    def emergency(self):
        return super().read()[1]

    @property
    def collision(self):
        return super().read()[2]

    @property
    def error(self):
        return super().read()[3]

    @property
    def busy(self):
        return super().read()[4]

    @property
    def movedone(self):
        return super().read()[5]

    @property
    def home(self):
        return super().read()[6]

    @property
    def zero(self):
        return super().read()[7]

    @property
    def resetting(self):
        return super().read()[8]

    @staticmethod
    def get_all_robot_state(indyshm):
        keys = ['busy', 'collision', 'emergency', 'error', 'home', 'movedone', 'ready', 'resetting', 'zero']
        st = {}
        for key in keys: st[key] = getattr(indyshm, key)
        return st


class ReporterState(ShmSecondWrapper):
    def __del__(self):
        lseek(self.shm.fd, self.offset, SEEK_SET)
        write(self.shm.fd, pack('b', 0))
        lseek(self.shm.fd, self.offset + 1, SEEK_SET)
        write(self.shm.fd, pack('b', 0))
        lseek(self.shm.fd, self.offset + 2, SEEK_SET)
        write(self.shm.fd, pack('b', 0))
        lseek(self.shm.fd, self.offset + 3, SEEK_SET)
        write(self.shm.fd, pack('b', 0))

    @property
    def taskProcess(self):
        return super().read()[0]

    @property
    def clipProcess(self):
        return super().read()[1]

    @property
    def logProcess(self):
        return super().read()[2]

    @property
    def zipProcess(self):
        return super().read()[3]

    @staticmethod
    def onTaskProcessState(indyshm):
        lseek(indyshm.shm.fd, indyshm.offset, SEEK_SET)
        return write(indyshm.shm.fd, pack('b', 1))

    @staticmethod
    def onClipProcessState(indyshm):
        lseek(indyshm.shm.fd, indyshm.offset + 1, SEEK_SET)
        return write(indyshm.shm.fd, pack('b', 1))

    @staticmethod
    def onLogProcessState(indyshm):
        lseek(indyshm.shm.fd, indyshm.offset + 2, SEEK_SET)
        return write(indyshm.shm.fd, pack('b', 1))

    @staticmethod
    def onZipProcessState(indyshm):
        lseek(indyshm.shm.fd, indyshm.offset + 3, SEEK_SET)
        return write(indyshm.shm.fd, pack('b', 1))

    @staticmethod
    def offTaskProcessState(indyshm):
        lseek(indyshm.shm.fd, indyshm.offset, SEEK_SET)
        return write(indyshm.shm.fd, pack('b', 0))

    @staticmethod
    def offClipProcessState(indyshm):
        lseek(indyshm.shm.fd, indyshm.offset + 1, SEEK_SET)
        return write(indyshm.shm.fd, pack('b', 0))

    @staticmethod
    def offLogProcessState(indyshm):
        lseek(indyshm.shm.fd, indyshm.offset + 2, SEEK_SET)
        return write(indyshm.shm.fd, pack('b', 0))

    @staticmethod
    def offZipProcessState(indyshm):
        lseek(indyshm.shm.fd, indyshm.offset + 3, SEEK_SET)
        return write(indyshm.shm.fd, pack('b', 0))

    @staticmethod
    def get_all_reporter_state(indyshm):
        keys = ['taskProcess', 'clipProcess', 'logProcess', 'zipProcess']
        st = {}
        for key in keys: st[key] = getattr(indyshm, key)
        return st

    @staticmethod
    def get_reporter_state_check(indyshm):
        keys = ['taskProcess', 'clipProcess', 'logProcess', 'zipProcess']
        result = 0
        for key in keys:
            result += getattr(indyshm, key)
        return True if result == 4 else False


class EventFiles:
    LOG_FOLDER = '/home/user/save-videos/'
    latest_log = ''

    @classmethod
    def _get_latest_log(cls):
        logs = glob.glob(EventFiles.LOG_FOLDER + '*.tgz')
        if len(logs) == 0: return ''
        logs.sort(key=os.path.getmtime, reverse=True)
        return logs[0]

    @classmethod
    def check_if_new_log(cls):
        tmp = cls._get_latest_log()
        if tmp != cls.latest_log:
            if len(cls.latest_log) == 0:
                cls.latest_log = tmp
                return False
            else:
                cls.latest_log = tmp
                return True
        return False

    @staticmethod
    def get_latest_clip():
        check_duration = 0.5
        timeout = BLACKBOX_CLIP_CHECK_TIMEOUT
        while timeout > 0:
            clips = glob.glob(EventFiles.LOG_FOLDER + 'video*.mp4')
            if len(clips) > 0:
                print(clips)
                return clips[0]
            time.sleep(check_duration)
            timeout -= check_duration
        print('no file...')
        return None


def login(s):
    res = s.post(URL + '/login', {'username': robot_sn, 'password': robot_sn})
    print(res.text)
    return 1 if res.status_code == 200 else 0


def logout(s):
    res = s.get(URL + '/logout')
    # print(res.status_code)
    return 0 if res.status_code == 200 else 1



def proc_info(title):
    print("------------------------------------------------------")
    print(title)
    print('Module name:', __name__)
    print('Parent process:', os.getppid())
    print('Process id:', os.getpid())
    print("------------------------------------------------------\n")


def task_counter(q, shm):
    """
    --------------- message queue check process -----------------
    Message Queue for posix_ipc [ http://semanchuk.com/philip/posix_ipc/ ]
    < Methods >
    MessageQueue(name, [flags = 0, [mode = 0600, [max_messages = QUEUE_MESSAGES_MAX_DEFAULT, [max_message_size = QUEUE_MESSAGE_SIZE_MAX_DEFAULT, [read = True, [write = True]]]]]])
    send(message, [timeout = None, [priority = 0]])
    receive([timeout = None]) < msg는 byte object 타입 >
    request_notification([notification = None])
    close()
    unlink()
    < Attributes >
    name (read-only)
    mqd (read-only)
    block
    max_messages (read-only)
    max_message_size (read-only)
    current_messages (read-only)
    """
    flag = True
    while flag:
        try:
            " indyshm is Dict type "
            print("\n************************ Task Process Initialization *****************************")

            print("<p1> Robot Id : %s [URL : %s]" % (robot_sn, URL))

            indyshmSCMState = ScmStateData(INDY_SHM_NAME, INDY_SHM_ROBOT_ADDR_SCM_STATE_STRUCT_DATA, 2)
            print("\n<p1> ControlState SHM : ", end="")
            print(indyshmSCMState)
            print(indyshmSCMState.getAllSCMState(indyshmSCMState))

            indyshmControlState = ControlState(INDY_SHM_NAME, INDY_SHM_ROBOT_ADDR_CTRL_STATUS_STRUCT_DATA, 9)
            print("\n<p1> ControlState SHM : ", end="")
            print(indyshmControlState)
            print(ControlState.get_all_robot_state(indyshmControlState))

            indyshmRobotState = RobotState(INDY_SHM_NAME, INDY_SHM_ROBOT_ADDR_STATE_STRUCT_DATA, 9)
            print("\n<p1> RobotState SHM : ", end="")
            print(indyshmRobotState)
            print(RobotState.get_all_state(indyshmRobotState))

            indyshmErrorCode = ErrorCode(INDY_SHM_NAME, INDY_SHM_ROBOT_ADDR_ERROR_CODE, 4)
            print("\n<p1> ErrorCode SHM : ", end="")
            print(indyshmErrorCode)
            print(ErrorCode.get_all_error(indyshmErrorCode))

            msgcounter = MessageCounter(INDY_SUPPORT_INDYGO_SHM_NAME, 0, 4)
            print("\n<p1> Msgcounter : ", msgcounter)

            mq = MessageQueue(INDY_NAME_POSIX_MSG_QUEUE, flags=O_CREAT)
            print("\n<p1> Mq : ", mq)

            print("\n<p1> Reporter SHM : ", shm)
            print(ReporterState.get_all_reporter_state(shm))
            ReporterState.onTaskProcessState(shm)
        except Exception as e:
            print("<p1>  Fail to initialize")
            print("*********************************************************************************\n")
            ReporterState.offTaskProcessState(shm)
            time.sleep(5)
            # sys.exit(-1)
        else:
            print("*********************************************************************************\n")
            flag = False
            time.sleep(1)


    # if indyshm == True and msgcounter == True and mq == True:
    #     flag = False
    # else:
    #     time.sleep(5)

    while mq.current_messages > 0:
        print('<p1> flush')
        mq.receive()

    # msgcounter.set(0)

    print("<P1> Enter the Queue")
    while True:
        " Struct 모듈 : pack, unpack etc..."
        ''
        '---------- MQ info --------'
        'struct IPCMessage          '
        '{                          '
        '    long mtype;            '
        '    long mDataLen;         '
        '    char mName[128];       '
        '    char mData[128];       '
        '}                          '
        '---------------------------'
        try:
            # print(msgcounter.counter)
            msgcounter.inc()
            t0 = datetime.datetime.now()
            data, pri = mq.receive()
        except Exception as e:
            print("<P1> Signal")
            while mq.current_messages > 0:
                print('<p1> flush')
                mq.receive()
            sys.exit()
        try:
            t1 = datetime.datetime.now()
            ReporterState.onTaskProcessState(shm)
            print("<p1> Queue Delay : ", t1-t0, t1.timestamp() - t0.timestamp())
            mtype, len = unpack('ll', data[:8])  # long is 4 byte ( mtype = 4, len = 4 )
            # print("type : ", type(data), " len : ", len, " pri : ", pri)
            msg = data[8:8 + data[8:].index(0)].decode('utf-8')  # 8부터 처음 0 나올 때 까지
            mdata = data[136:136 + data[136:].index(0)].decode('utf-8')  # 8 + 128 부터 0 나올 때 까지
            print("<p1> mtype [%s]" % mtype, ", msg [%s]" % msg, ", mdata [%s]" % mdata, ", msg counter [%s]" % msgcounter.counter)

            q.put_nowait((mtype, msg, mdata))
        # except posix_ipc.posix_ipc.SignalError:
        #     print("<P1> Signal")
        #     while mq.current_messages > 0:
        #         print('<p1> flush')
        #         mq.receive()
        #     sys.exit()
        except SystemExit as e2:
            ReporterState.offTaskProcessState(shm)
            print("<P1> System Exit> ", e2)
            sys.exit()

        except Exception as e:
            ReporterState.offTaskProcessState(shm)
            print("<p1> Exception Queue :", e)
            print(ReporterState.get_all_reporter_state(shm))
            while mq.current_messages > 0:
                print('<p1> flush')
                mq.receive()
            time.sleep(5)
            continue


def reporter(q, shm, flag=0):
    'report loop'

    # POST(s, '/kpiInit', json=json.dumps({'sn': robot_sn}))
    print("<Reporter> Reporter Func start")
    while True:
        try:
            indyshm_control_state = ControlState(INDY_SHM_NAME, INDY_SHM_ROBOT_ADDR_CTRL_STATUS_STRUCT_DATA, 9)
            indyshm_robot_state = RobotState(INDY_SHM_NAME, INDY_SHM_ROBOT_ADDR_STATE_STRUCT_DATA, 9)
            indyshm_error_code = ErrorCode(INDY_SHM_NAME, INDY_SHM_ROBOT_ADDR_ERROR_CODE, 4)
            indyshm_scm_state = ScmStateData(INDY_SHM_NAME, INDY_SHM_ROBOT_ADDR_SCM_STATE_STRUCT_DATA, 2)
        except Exception:
            time.sleep(5)
        else:
            break

    while True:
        try:
            if flag == 0:
                print("<Reporter> Session & Login : ", end="")
                s = requests.Session()
                flag = login(s)
                time.sleep(1)

            # Check message
            # print("Q Size : %d, IP : %s, SN : %s" % (q.qsize(), URL, robot_sn))
            while q.qsize() > 0:
                mtype, msg, mdata = q.get()
                # print("<Type> mtype: %s, msg: %s, mdata: %s" % (type(mtype), type(msg), type(mdata)))
                # todo :  mtype description
                '-----------------------------------------------------------'
                '        mtype Range    |     Description                   '
                '           1 ~ 99      |     Operation command             '
                '         100 ~ 199     | Server configuration information  '
                '         200 ~ 299     |     IndySW information            '
                '-----------------------------------------------------------'
                '             1         |        Count                      '
                '             2         |        Mean                       '
                '           100         |        KPI configuration          '
                '           101         |        IP address                 '
                '           102         |        Robot S/N                  '
                '           200         |        IndySW version             '
                '-----------------------------------------------------------'
                if mtype == 1:
                    print("<Reporter> Received Count( %s %s )" % (mtype, msg))
                    # todo : Count
                    POST(s, '/report_robot_opdata', json=json.dumps({msg: 1.0}))
                elif mtype == 2:
                    print("<Reporter> Received Mean( %d %s %s )" % (mtype, msg, mdata))
                    # todo Mean
                    _dic = {}
                    temp = mdata.split(',')
                    if len(temp) == 6:
                        for i in range(len(temp)):
                            _dic['joint' + str(i)] = float(temp[i])
                    else:
                        _dic[msg] = float(mdata)
                    # dic = {msg: _dic}
                    print("<Reporter> DIC : ", _dic)
                    POST(s, '/report_robot_opdata', json=json.dumps(_dic))
                elif mtype == 3:
                    print("<Reporter> Received Undefined( %s %s )" % (mtype, msg))
                    # todo :
                    POST(s, '/undefined_post', json=json.dumps({msg, mdata}))
                elif mtype == 100:
                    print("<Reporter> KPI configuration( %s, %s )" % (msg, mdata))
                    # todo POST MONGO DB for admin field
                    POST(s, '/report_kpi_string', json=json.dumps({msg: mdata}))
                elif mtype == 101:
                    print("<Reporter> IP Address( %s, %s )" % (msg, mdata))
                    # URL = 'http://' + mdata
                    # todo 그냥 test_config.py의 url ip 주소 변경만 하면 됨
                elif mtype == 102:
                    print("<Reporter> Robot S/N( %s, %s )" % (msg, mdata))
                    # robot_sn = mdata
                    # todo IP랑 마찬가지 (But, 현재는 sn은 위에 전역변수로 되있음. 변경필요)
                elif mtype == 200:
                    print("<Reporter> Received IndySW version( %s )" % msg)
                    # todo 어떻게 할지 미정 -> 이사님께서 Redis에 일단 올리도록, 추후 사용
                    POST(s, '/report_indySW_ver', json=json.dumps({msg: mdata}))
            # send status
            print("\n===============================================================================================")
            ScmStateData.turnOnReporter(indyshm_scm_state)
            if ReporterState.get_reporter_state_check(shm):
                ScmStateData.turnOnServer(indyshm_scm_state)
            else:
                ScmStateData.turnOffServer(indyshm_scm_state)
            state_dic = {}
            state_dic.update(ControlState.get_all_robot_state(indyshm_control_state))
            state_dic.update(RobotState.get_all_state(indyshm_robot_state))
            state_dic.update(ErrorCode.get_all_error(indyshm_error_code))
            state_dic.update(ScmStateData.getAllSCMState(indyshm_scm_state))
            state_dic.update(ReporterState.get_all_reporter_state(shm))
            state_dic['cam'] = 1
            POST(s, '/report_robot_status', json=json.dumps(state_dic), timeout=10)
            print(state_dic)
            print("===============================================================================================")

            # print(ReporterState.get_reporter_state_check(shm))
            # send event if required
            if EventFiles.check_if_new_log():
                # ex) '14-videolog-03-05-2019-18-41-35.tgz'
                logfile = EventFiles.latest_log[len(EventFiles.LOG_FOLDER):]
                print('<Reporter> Logfile', logfile)
                code = int(logfile[:2])
                ts = datetime.datetime.strptime(logfile[12:-4], '%m-%d-%Y-%H-%M-%S')
                POST(s, '/report_robot_event', json={'time': str(ts), 'code': code, 'log': EventFiles.latest_log})
            time.sleep(0.5)
        except SystemExit as e2:
            ScmStateData.turnOffReporter(indyshm_scm_state)
            print("<Reporter System Exit> ", e2)
            s.close()
            print(ScmStateData.getAllSCMState(indyshm_scm_state))
            sys.exit()
        except requests.exceptions.ConnectionError:
            t1 = t0 = datetime.datetime.now()
            ScmStateData.turnOffReporter(indyshm_scm_state)
            print("<Reporter> Connect Error !!")
            while True:
                print("<Reporter> Reconnected . . . ", t1.timestamp() - t0.timestamp())
                try:
                    res = s.post(URL + '/login', {'username': robot_sn, 'password': robot_sn}, timeout=5)
                    if res.status_code == 200:
                        break
                except Exception:
                    time.sleep(5)
                t1 = datetime.datetime.now()
        except Exception as e:
            print("<Reporter> Exception Session Close : ", flag)
            ScmStateData.turnOffReporter(indyshm_scm_state)
            s.close()
            time.sleep(5)
            continue
    logout(s)
    s.close()

def zip_uploader(shm):
    proc_info('<p4> Zip Uploader')

    path = os.getcwd() + "/saveConfig/"
    if not os.path.exists(path):
        os.makedirs(path)
    flag = True
    while flag:
        try:
            print("<p4> Session & Login (Path : %s) : " % os.getcwd(), end="")
            ReporterState.onZipProcessState(shm)
            s = requests.Session()
            login(s)
            try:
                messages = SSEClient(URL + '/stream?channel=%s_zip' % robot_sn)
            except SystemExit:
                print("<P4 Zip uploader System Exit>")
                s.close()
                sys.exit()
            for msg in messages:
                print('<p4> zip msg', msg.data, type(msg.data), len(str(msg)))
                zip_name = msg.data + "_conf_file"
                # ZIP_PATH = "../robot/xml_config/" + zip_name + ".zip"
                ZIP_PATH = path + zip_name + ".zip"

                if os.path.exists(ZIP_PATH):
                    print("<p4> Already exist the zip file")
                else:
                    # PATH = "../robot/xml_config/"
                    xmlPath = '/home/user/release/RobotSpecs/Indy7/'
                    filenames = os.listdir(xmlPath)
                    xml_list = []
                    for filename in filenames:
                        full_filename = os.path.join(xmlPath, filename)
                        ext = os.path.splitext(filename)[-1]
                        if ext == '.xml':
                            xml_list.append(filename)
                            if filename is filenames[-1]:
                                print(filename)
                            else:
                                print(filename, end=", ")

                    # for i in xml_list:
                    #     print(i)
                    _item = {}

                    # todo : compress the xml files.
                    test_zip = zipfile.ZipFile(ZIP_PATH, 'w')
                    for folder, subfolders, files in os.walk(xmlPath):
                        for file in files:
                            if file.endswith('.xml'):
                                test_zip.write(os.path.join(folder, file), file, compress_type=zipfile.ZIP_DEFLATED)

                    # todo : Zip file을 binary화
                    with open(ZIP_PATH, 'rb') as f:
                        # encoded = f.read()
                        # _item[zip_name] = encoded
                        # print(encoded, type(encoded))
                        res = POST(s, '/config_down/' + robot_sn, files={'file': f})
                    print("<p4> Res : ", res)

        except SystemExit as e2:
            ReporterState.offZipProcessState(shm)
            print("<P4 Zip uploader System Exit> ", e2)
            s.close()
            print(ReporterState.get_all_reporter_state(shm))
            sys.exit()
        except requests.exceptions.ConnectionError:
            t1 = t0 = datetime.datetime.now()
            ReporterState.offZipProcessState(shm)
            print("<P4> Connect Error !!")
            while True:
                print("<P4> Reconnected . . . ", t1.timestamp() - t0.timestamp())
                try:
                    res = s.post(URL + '/login', {'username': robot_sn, 'password': robot_sn}, timeout=5)
                    if res.status_code == 200:
                        break
                except requests.exceptions.RequestException:
                    pass
                t1 = datetime.datetime.now()
        except Exception as e:
            ReporterState.offZipProcessState(shm)
            print("<p4> Exception Session Close : ", flag)
            s.close()
            time.sleep(5)
            continue

    logout(s)
    s.close()

def clip_uploader(shm):
    proc_info('<p2> Clip Uploader')
    flag = True
    while flag:
        try:
            print("<p2> Session & Login : ", end="")
            ReporterState.onClipProcessState(shm)
            s = requests.Session()
            login(s)
            try:
                messages = SSEClient(URL + '/stream?channel=%s_clip' % robot_sn)
            except SystemExit:
                print("<P2 Clip uploader System Exit>")
                s.close()
                sys.exit()
            for msg in messages:
                print('<p2> clip msg', msg.data)
                if EventFiles.get_latest_clip():
                    with open(EventFiles.get_latest_clip(), 'rb') as f:
                        print("<p2> [POST] Upload Clip", end=" ")
                        print(f)
                        res = POST(s, '/upload_blackbox_clip', files={'file': f})
                else:
                    print("<p2> [POST] No Camera. . . ")
                    res = POST(s, '/upload_blackbox_clip', files={'file': ('No Camera', '')})
                print(res.text)
        except SystemExit as e2:
            ReporterState.offClipProcessState(shm)
            print("<P2 Clip uploader System Exit> ", e2)
            s.close()
            print(ReporterState.get_all_reporter_state(shm))
            sys.exit()
        except requests.exceptions.ConnectionError:
            t1 = t0 = datetime.datetime.now()
            ReporterState.offClipProcessState(shm)
            print("<P2> Connect Error !!")
            while True:
                print("<P2> Reconnected . . . ", t1.timestamp() - t0.timestamp())
                try:
                    res = s.post(URL + '/login', {'username': robot_sn, 'password': robot_sn}, timeout=5)
                    if res.status_code == 200:
                        break
                except requests.exceptions.RequestException:
                    pass
                t1 = datetime.datetime.now()
        except Exception as e:
            ReporterState.offClipProcessState(shm)
            print("<p2> Exception Session Close : ", flag)
            s.close()
            print(e)
            time.sleep(5)
            continue
    logout(s)
    s.close()

def log_uploader(shm):
    proc_info('<p3> Log Uploader')
    flag = True
    while flag:
        try:
            print("<p3> Session & Login : ", end="")
            ReporterState.onLogProcessState(shm)
            s = requests.Session()
            login(s)
            try:
                messages = SSEClient(URL + '/stream?channel=%s_log' % robot_sn)
            except SystemExit:
                print("<P3 Log uploader System Exit>")
                s.close()
                sys.exit()
            for msg in messages:
                print('<p3> log msg', msg.data)
                data = json.loads(msg.data)
                if os.path.exists(data['log']):
                    with open(data['log'], 'rb') as f:
                        print("<p3> [POST] Upload Log", end=" ")
                        print(f)
                        res = POST(s, '/upload_event_data', files={'file': f, 'evid': (data['message'], '')})
                else:
                    print("<p3> [POST] No Log File. . . ")
                    res = POST(s, '/upload_event_data', files={'file': ('No File', ''), 'evid': (data['message'], '')})
                print(res.text)
        except SystemExit as e2:
            ReporterState.offLogProcessState(shm)
            print("<P3 Log uploader System Exit> ", e2)
            s.close()
            print(ReporterState.get_all_reporter_state(shm))
            sys.exit()
        except requests.exceptions.ConnectionError:
            t1 = t0 = datetime.datetime.now()
            ReporterState.offLogProcessState(shm)
            print("<P3> Connect Error !!")
            while True:
                print("<P3> Reconnected . . . ", t1.timestamp()-t0.timestamp())
                try:
                    res = s.post(URL + '/login', {'username': robot_sn, 'password': robot_sn}, timeout=5)
                    if res.status_code == 200:
                        break
                except requests.exceptions.RequestException:
                    pass
                t1 = datetime.datetime.now()
        except Exception as e:
            ReporterState.offLogProcessState(shm)
            print("<p3> Exception Session Close : ", flag)
            s.close()
            print()
            time.sleep(5)
            continue
    logout(s)
    s.close()


def sig_handler(signum, frame):
    global pid_list
    print('SIGNAL RECEIVED:', signum, frame)
    sys.exit()


if __name__ == '__main__':
    q = Queue()
    shm = ReporterState(INDY_REPORTER_SHM_NAME, 10, 4)
    time.sleep(1)

    p1 = Process(target=task_counter, args=(q, shm, ))
    time.sleep(2)
    p2 = Process(target=clip_uploader, args=(shm, ))
    p3 = Process(target=log_uploader, args=(shm, ))
    p4 = Process(target=zip_uploader, args=(shm, ))
    pid_list = [p1.pid, p2.pid, p3.pid, p4.pid]
    print("SIGNAL Handler for TERM, INT")
    signal.signal(signal.SIGTERM, sig_handler)
    signal.signal(signal.SIGINT, sig_handler)
    p1.start()
    p2.start()
    p3.start()
    p4.start()
    reporter(q, shm)
    q.close()
    q.join_thread()
    p4.join()
    p3.join()
    p2.join()
    p1.join()
