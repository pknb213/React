import requests
import datetime
import json
import sys
from utils import *
from test_config import URL, POST, GET
import time

s = requests.Session()

res = s.post(URL+'/login', {'username':'r1', 'password':'r1'})
print(res.text)

# todo : selected True & False
nwk_connected = True
if nwk_connected:
    sys.argv.append('s')
    print(sys.argv)

    if len(sys.argv) == 1:
        print('Usage:%s s|o|e' % sys.argv[0])
    elif sys.argv[1] == 's':
        POST(s, '/report_robot_status', json=json.dumps({'state': 1, 'health': 'good', 'ready': 1}))

time.sleep(1)

date = str(utc.localize(datetime.utcnow()).astimezone(KST).strftime(fmt))
POST(s, '/config_down/r1', json=json.dumps({'date': date}))

