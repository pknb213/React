import requests
import json
import datetime
import sys
from pprint import pprint

auth_url = 'http://112.175.172.106:9137/extr/athn/devCommChAthn'

headers = {
	'Message-Exchange-Pattern': 'one-way-ack',
	'Message-Type': 'request',
	'Header-Type': 'basic',
	'Encryption-Usage': 'no',
	'Protocol-Version': '01.00',
	'Trm-Transaction-ID': '1555472010000',
	'Compression-Usage': 'no',
	'Method-Type': '/extr/athn/devCommChAthn',
	'Encoding-Type': 'json'
    }

data = {
	"extrSysId":"FACTORY_NM",
	"devId":"emulator",
	"athnRqtNo":"123456",
	"msgHeadVO":{"mapHeaderExtension":{}}
}

pprint(headers)
pprint(data)

res = requests.post(auth_url, headers=headers, json=data)

if res.status_code != 200:
	print('Fail to authenticate')
	sys.exit(0)
resp_data = res.json()
authno = resp_data['athnNo']
print('Auth no:', authno)

report_url = 'http://112.175.172.106:9137/extr/colec/itgData/recv'
headers = {
	'Message-Exchange-Pattern': 'one-way-ack',
	'Message-Type': 'request',
	'Header-Type': 'basic',
	'Channel-Auth-Token': authno,
	'Encryption-Usage': 'no',
	'Protocol-Version': '01.00',
	'Trm-Transaction-ID': '1555472130001',
	'Compression-Usage': 'no',
	'Method-Type': '/extr/colec/itgData/recv',
	'Encoding-Type': 'json'
}

data = {
	"extrSysId": "FACTORY_NM",
	"devColecDataVOs": [
		{
			"devId": "emulator",
			"colecRowVOs": [
				{ #"occDt": "2019-04-17 12:35:35.598",
				 "snsnDataInfoVOs": [{"dataTypeCd": "Temperature6", "snsnVal": 26.8},
									 {"dataTypeCd": "Temperature5", "snsnVal": 25.8},
									 {"dataTypeCd": "Temperature4", "snsnVal": 24.8},
									 {"dataTypeCd": "Temperature3", "snsnVal": 23.8},
									 {"dataTypeCd": "Temperature2", "snsnVal": 22.8},
									 {"dataTypeCd": "Temperature1", "snsnVal": 21.2},
									 {"dataTypeCd": "PowerConsumption", "snsnVal": 100.8}],
				 "strDataInfoVOs": [{"snsnTagCd": "LoopCount", "strVal": "Signal"},
									{"snsnTagCd": "ReceiveDate",
									 "strVal": "20190417091322"},
									{"snsnTagCd": "EventMessage",
									 "strVal": "Collision"},
									{"snsnTagCd": "State", "strVal": "busy"},
									{"snsnTagCd": "RobotNO", "strVal": "1"},
									{"snsnTagCd": "EventCode", "strVal": "00"}],
				 }
			]
		}
	],
	"msgHeadVO": {"mapHeaderExtension": {}}
}

res = requests.post(report_url, headers=headers, json=data)

if res.status_code != 200:
	print('Fail to report')
	sys.exit(0)
resp_data = res.json()
print(resp_data)