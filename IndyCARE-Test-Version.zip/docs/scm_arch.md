# 코드 구조 설명 

## 문서의 목적
- SCM 서버 코드 구조 설명
- 참고) SRS 및 SDS

## 사전 지식 
- python3 (decorator, process, lambda, etc...)
- http protocol 
- Flask/jinja2
- sse (server sent event)
- html5/javascript(jquery, jsgrid, etc)
- mongodb(pymongo)
- influxdb
- redis
- posix ipc(shared memeroy, message queue)

## Usecases

![usecases](out/usecases/diagram.svg)

## Activity Diagrams
- 고객/사이트/로봇 관리
  
![manage](out/act_manage/diagram.svg)

- 로봇 목록 조회

![robot list](out/act_robot_list/diagram.svg)

- 로봇 상세 조회

![robot detail](out/act_robot_detail/diagram.svg)

- KPI

![kpi](out/act_kpi/diagram.svg)

- 로봇 상태 업로드 

![status update](out/act_status_update/diagram.svg)

- 블랙박스 영상 취득 
  
![blackbox](out/act_blackbox/diagram.svg)

- 디버그 로그 취득 

![debug log](out/act_event_log/diagram.svg)

## Database Schema

![schema](out/db_schema/diagram.svg)