from utils import *


def get_sites():
    owners = {}
    for site in sites.find():
        owner = customers.find_one({'_id': site['owner_id']})
        yield {'name': site['name'], 'info': site['info'], 'owner': owner['name']}


app.jinja_env.globals.update(current_user=current_user)
app.jinja_env.globals.update(get_sites=get_sites)

# flask-login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"


# callback to reload the user object
@login_manager.user_loader
def load_user(userid):
    return User(userid)


@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user.is_authenticated: return redirect(url_for('home'))
    if request.method == 'POST':
        if check_user(request.form['username'], request.form['password']):
            user = User(request.form['username'])
            login_user(user)
            print('User', user.name, 'logged in from', user.permission)
            if user.permission == 'admin':
                return redirect(url_for('admin_customer'))
            elif user.permission == 'developer':
                return redirect(url_for('developer_robot_list'))
            elif user.permission == 'maintainer':
                return redirect(url_for('maintainer_robot_list'))
            return 'LOGIN'
        elif check_robot(request.form['username'], request.form['password']):
            user = Robot(request.form['username'])
            login_user(user)
            print('Robot', user.id, 'logged')
            return 'LOGIN'
        else:
            flash("ID & PW를 확인해주세요")
            # return Response("ID & PW Fail", status=404)
            return redirect(url_for('login'))
    else:
        return render_template('auth_login.html')


@app.route("/logout")
@login_required
def logout():
    print('User', current_user.email, 'logged out')
    logout_user()
    session.pop('logged_in', None)
    flash('You were logged out')
    return redirect(url_for('home'))


@app.route("/add_customer", methods=['POST'])
def add_customer():
    customer_name = request.form['name']
    customer_location = request.form['location']
    customer_info = request.form['info']
    customer_header = request.form['header']

    if customers.find_one({'name': customer_name}):
        return Response('Duplicate name', status=404)
    c = customers.insert_one({'name': customer_name, 'location': customer_location,
                              'info': customer_info, 'header': customer_header})
    return Response('ok')

