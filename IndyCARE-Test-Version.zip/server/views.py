import os
from utils import *
from robots import Robot
from sites import Admin
from reporter_server import Reporter


@app.route('/')
def home():
    if current_user.is_authenticated:
        print("Enter Email: %s Permision: %s Name: %s" %(current_user.email, current_user.permission, current_user.name))
    if not current_user.is_authenticated:
        print("Not Authenticated")
        return redirect(url_for('login'))
    elif current_user.permission == 'admin': return redirect(url_for('admin_customer'))
    elif current_user.permission == 'developer': return redirect(url_for('developer_robot_list'))
    elif current_user.permission == 'maintainer': return redirect(url_for('maintainer_robot_list'))
    elif current_user.permission == 'indygo': return redirect(url_for('indyGo'))
    else:
        return Response(current_user.email + ' logged in', status=200)
        # return render_template('login.html')


@app.route('/view/clip/<robot>')
def view_blackbox_clip(robot):
    return render_template('clip_view.html', url = url_for('get_blackbox_clip', sn=robot), robot=robot)


@app.route('/view/indygo')
@LoginRequired('indygo')
def indyGo():
    return render_template('indygo.html')


@app.route('/view/admin/<customer>')
@LoginRequired('admin')
def admin_site(customer):
    customer_name = customers.find_one({'_id':objectid.ObjectId(customer)})['name']
    return render_template('admin_site.html', customer_id=customer, customer_name=customer_name)


@app.route('/view/admin/<customer>/<site>')
@LoginRequired('admin')
def admin_robot(customer, site):
    customer_name = customers.find_one({'_id': objectid.ObjectId(customer)})['name']
    site_name = sites.find_one({'_id': objectid.ObjectId(site)})['name']
    return render_template('admin_robot.html', customer_id=customer,  site_id=site, customer_name=customer_name, site_name=site_name)


@app.route('/view/maintenance')
@LoginRequired('developer,admin,maintainer')
def maintenance():
    return render_template('maintenance.html')


# todo : Please LoginRequired don't enter the space or null between permission
@app.route('/view/maintenance/robot/<sn>')
@LoginRequired('developer,admin,maintainer')
def maintenance_robot(sn):
    if sn == 'favicon.ico':
        return Response('ok')
    r = robots.find_one({'sn': sn})
    kpi = []
    if 'kpi' not in r:
        return Response('KPI value is empty', status=404)
    elif r is None:
        return Response('Defined robot sn : %s' % sn, status=404)
    elif r['kpi'] == '':
        return Response('KPI value is empty', status=404)
    for item in r['kpi'].split(';'):
        values = item.split(',')
        kpi.append({'desc': values[0], 'period': values[1], 'method': values[2]})
    return render_template('robot_detail.html', sn=sn, robot=r, kpi=kpi)


# todo : Refactoring Routing function

@app.route('/userList')
@LoginRequired('admin')
def admin_users():
    return render_template('user_list.html')


@app.route('/companyList')
@LoginRequired('admin')
def admin_customer():
    return render_template('company_list.html')


@app.route('/userRegister')
@LoginRequired('admin')
def admin_user_register():
    return render_template('user_register.html')


@app.route('/companyRegister')
@LoginRequired('admin')
def admin_customer_register():
    return render_template('company_register.html')


@app.route('/companyList/<string:company>')
@LoginRequired('admin')
def admin_company(company):
    customer_name = customers.find_one({'_id': objectid.ObjectId(company)})['name']
    return render_template('site_list.html', customer_id=company, customer_name=customer_name)


@app.route('/companyList/<string:company>/siteList/<site>')
@LoginRequired('admin')
def admin_company_site(company, site):
    site_name = sites.find_one({'_id': objectid.ObjectId(site)})['name']
    customer_name = customers.find_one({'_id': objectid.ObjectId(company)})['name']
    return render_template('robot_list.html', customer_name=customer_name, customer_id=company, site_id=site, site_name=site_name)


@app.route('/developerRobotList')
@LoginRequired('developer')
def developer_robot_list():
    return render_template('devel_robot_list.html')


@app.route('/robotList')
@LoginRequired('admin,developer,maintainer')
def maintainer_robot_list():
    print("<Maintainer> Company : ", current_user.company, current_user.name)
    c = customers.find_one({'name': current_user.company})
    if None in c:
        company = None
    else:
        company = c['_id']
    print(">>>", company)
    return render_template('maint_robot_list.html', customer_id=company)


@app.route('/robotList/<company>/<site>/<sn>')
@LoginRequired('')
def robot_information(company, site, sn):
    r = robots.find_one({'sn': sn})
    kpi = []
    if 'kpi' not in r:
        return Response('KPI value is empty', status=404)
    elif r is None:
        return Response('Defined robot sn : %s' % sn, status=404)
    elif r['kpi'] == '':
        return Response('KPI value is empty', status=404)
    for item in r['kpi'].split(';'):
        values = item.split(',')
        kpi.append({'desc': values[0], 'period': values[1], 'method': values[2], 'axis': values[3]})
    print(sn, kpi)
    # print("LRANGE : ", cache.lpop('kpi_str', 0, -1))
    return render_template('robot_detail.html', costomer_id=company, site_id=site, sn=sn, robot=r, kpi=kpi)

















