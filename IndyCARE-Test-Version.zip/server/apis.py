from utils import *
from robots import Robot
from sites import Admin
from users import Users
from reporter_server import Reporter


# indygo api
@app.route("/robotstatus/<sn>")
@LoginRequired()
def get_robot_status(sn):
    api_log('robotstatus', sn)
    res = Robot.get_status(sn)
    return jsonify(res)


# 조업데이터
@app.route("/opdata/<sn>/kpi")
@LoginRequired()
def get_operation_data_keys(sn):
    api_log('opdata/itmes', sn)
    return Robot.get_opdata_keys(sn)


# 최근 평균
@app.route("/opdata/<sn>/latest/<interval>")
def get_latest_operation_data(sn, interval):
    return Robot.get_latest_operation_data(sn, interval)


@app.route("/opdata/<sn>/<key>/recent/<period>/<interval>")
def get_operation_history_data(sn, key, period, interval):
    return Robot.get_operation_data_history(sn, key, period, interval)


regular_unit = {
    'year':('1y', '1M'),
    'month':('1M', '1d'),
    'week':('1w', '1d'),
    'day':('1d', '1h'),
    'hour':('1h', '10m')
}


@app.route("/opdata/<sn>/<key>/recent/<unit>")
@app.route("/opdata_stat/<sn>/<key>/recent/<unit>/<aggregation>/<axis>")
def get_operation_history_data_unit(sn, key, unit, aggregation='mean', axis='1'):
    print("Opdata: %s, Key: %s, Unit: %s, Agg: %s, Axis: %s" % (sn, key, unit, aggregation, axis))
    if unit not in regular_unit:
        Response('Unknown time unit')
    period, interval = regular_unit[unit]
    return Robot.get_operation_data_history(sn, key, period, interval, None, aggregation, axis)


@app.route("/opdata/<sn>/<key>/regular/<unit>")
@app.route("/opdata/<sn>/<key>/regular/<unit>/<aggregation>")
def get_operation_regular_history_data(sn, key, unit, aggregation='mean'):
    if unit not in regular_unit:
        Response('Unknown time unit')
    period, interval = regular_unit[unit]
    return Robot.get_operation_data_history(sn, key, period, interval, unit, aggregation)


#  raw 데이터 확인용  : key=<key>&limit=<limit>
@app.route("/raw_opdata/<sn>")
@LoginRequired()
def get_operation_data(sn):
    args = form2dict(request.args)
    api_log('raw_opdata', sn, args)
    keys = args['key'] if 'key' in args else '*'
    limit = int(args['limit']) if 'limit' in args else 100
    filter = ''
    return Robot.get_raw_operation_data(sn, keys, filter, limit)


@app.route("/raw_opdata/<sn>/<keys>/<period>")
@LoginRequired()
def get_operation_data_ex(sn, keys, period):
    args = form2dict(request.args)
    api_log('raw_opdata', sn, keys, period, args)
    limit = int(args['limit']) if 'limit' in args else 100
    if ',' not in period:
        filter = ' WHERE time > now() - %s ' % period
    else:
        fr, to = period.split(',')
        filter = "WHERE time >= \'%s\' AND time <= \'%s\'" % (fr, to)
    return Response(Robot.get_raw_operation_data(sn, keys, filter, limit))


# 블랙박스 데이터
@app.route("/clips/<sn>/<cam>")
def get_blackbox_clip_cam(sn, cam):
    print(">> get_blackbox_clip_cam %s" % cam)
    return Robot.get_blackbox_clip(sn, cam)


@app.route("/clips/<sn>")
def get_blackbox_clip(sn):
    print(">> get_blackbox_clip")
    return Robot.get_blackbox_clip(sn, 1)


@app.route("/clips/<sn>/check")
def get_blackbox_camera_check(sn):
    return Robot.check_camera(sn)


# admin api
@app.route("/admin/users")
@LoginRequired('admin')
def get_users():
    if request.method == 'GET':
        return Users.get_users()


@app.route('/admin/customer', methods=['POST', 'GET', 'PUT', 'DELETE'])
@LoginRequired('admin')
def customer_crud():
    if request.method == 'GET':
        return Admin.get_customers()
    req = form2dict(request.form)
    Admin.validate_request(req, 'info', 'location')
    if request.method == 'POST':
        return Admin.add_customer(req)
    elif request.method == 'PUT':
        return Admin.update_customer(req)
    elif request.method == 'DELETE':
        return Admin.delete_customer(req)


@app.route('/admin/site/<customer>', methods=['POST', 'GET', 'PUT', 'DELETE'])
@LoginRequired('admin')
def site_crud(customer):
    _id = objectid.ObjectId(customer)
    if not _id: return Response('Invalid customer id', status=404)
    if request.method == 'GET':
        return Admin.get_sites(_id)
    req = form2dict(request.form)
    Admin.validate_request(req, 'info')
    if request.method == 'POST':
        return Admin.add_site(_id, req)
    elif request.method == 'PUT':
        return Admin.update_site(_id, req)
    elif request.method == 'DELETE':
        return Admin.delete_site(_id, req)


@app.route('/admin/robot/<customer>/<site>', methods=['POST', 'GET', 'PUT', 'DELETE'])
@LoginRequired('admin')
def robot_crud(customer, site):
    customer_id = objectid.ObjectId(customer)
    if not customer_id: return Response('Invalid customer id', status=404)
    if site == '*':
        site_id = None
    else:
        site_id = objectid.ObjectId(site)
        if not site_id: return Response('Invalid site id', status=404)
    if request.method == 'GET':
        return Admin.get_robots(customer_id, site_id)

    req = form2dict(request.form)
    Admin.validate_request(req, 'info', 'kpi')
    if request.method == 'POST':
        return Admin.add_robot(customer_id, site_id, req)
    elif request.method == 'PUT':
        return Admin.update_robot(customer_id, site_id, req)
    elif request.method == 'DELETE':
        return Admin.delete_robot(customer_id, site_id, req)


# developer api
@app.route('/maintenance/list')
@LoginRequired('admin,developer,maintainer')
def robot_list_adapter():
    return Robot.jsGridControl(request.args)


@app.route("/get_customers")
@LoginRequired('admin,developer')
def get_customer():
    api_log('get customer')
    return Admin.get_customers()


@app.route("/get_sites/<customer>") # customer
@LoginRequired('admin,developer')
def get_sites(customer):
    api_log('get sites', request.args)
    return Admin.get_sites(objectid.ObjectId(customer), form2dict(request.args))


@app.route("/get_robots/<customer>/<site>") # customer [,site]
@LoginRequired('admin,developer')
def get_robots(customer, site):
    site = objectid.ObjectId(site) if site != '*' else '*'
    api_log('get robots', request.args)
    return Admin.get_robots(objectid.ObjectId(customer), site, form2dict(request.args))


@app.route("/get_robot_history/<sn>")
@LoginRequired('admin,developer,maintainer')
def get_robot_history(sn):
    print("Args : ", request.args, " Type: %s", type(request.args))
    args = form2dict(request.args)
    api_log('get_robot_history', sn, args)
    limit = int(args['limit']) if 'limit' in args else 100
    return Robot.get_history(sn, limit)


@app.route("/get_event_data/<evid>")
@LoginRequired('admin,developer,maintainer')
def get_event_data(evid):
    api_log('get_event_data', evid)
    return Robot.get_event_file(sse, evid)


# robot controller api
@app.route('/report_robot_status', methods=["POST"])
@LoginRequired('-indygo')
def upload_robot_status():
    # api_log('report_robot_status', request.json)
    return Robot.update_state(current_user.id, json.loads(request.json))


@app.route('/report_robot_opdata', methods=["POST"])
@LoginRequired('-indygo')
def upload_robot_opdata():
    # api_log('report_robot_opdata', request.json)
    return Robot.update_opdata(current_user.id, json.loads(request.json))


@app.route('/report_robot_event', methods=["POST"])
@LoginRequired('-indygo')
def upload_robot_event():
    api_log('report_robot_event', request.json)
    return Robot.add_event(current_user.id, request.json)


@app.route('/upload_event_data', methods=["POST"])
@LoginRequired('-indygo')
def upload_event_data():
    api_log('upload_event_data', request.files['file'].filename, request.files['evid'].filename)
    evid = request.files['evid'].filename
    if request.files['file'].name == 'No File':
        return Robot.upload_event_file(current_user.id, evid, None)
    else:
        return Robot.upload_event_file(current_user.id, evid, request.files['file'])


@app.route('/upload_blackbox_clip', methods=["POST"])
@LoginRequired('-indygo')
def upload_blackbox_clip():
    api_log('upload_blackbox_clip', request.files['file'].filename)
    if request.files['file'].name == 'No Camera':
        return Robot.update_blackbox_clip(current_user.id, None)
    else:
        return Robot.update_blackbox_clip(current_user.id, request.files['file'])


# SW Upgrade Status APIs
# JS Grid api
@app.route('/sw_upgrade_list/<sn>', methods=['GET', 'POST', 'PUT', 'DELETE'])
@LoginRequired('-indygo')
def sw_upgrade_list(sn):
    args = form2dict(request.args)
    api_log('sw_upgrade_list', sn, args)
    if request.method == 'GET':
        return Robot.get_sw_upgrade_history(sn)
    print("\n")
    req = form2dict(request.form)
    # print(req)
    if request.method == 'POST':
        return Robot.post_sw_upgrade_history(sn, req)
    elif request.method == 'PUT':
        pass
    elif request.method == 'DELETE':
        pass
    else:
        return Response("Invalid RESTful APIs...", status=404)


# External POST api
@app.route('/sw_upgrade_history/<sn>', methods=['POST'])
@LoginRequired('-indygo')
def sw_upgrade_status(sn):
    api_log('sw_upgrade_history', sn, request.json)
    # print(current_user.id)  # sn
    req = json.loads(request.json)  # string to dict
    # print(type(req))
    return Robot.post_sw_upgrade_history(sn, req)


# Get XML list api
@app.route('/get_xml_list/<sn>', methods=['GET'])
@LoginRequired('-indygo')
def get_xml_list(sn):
    api_log('get_xml_list', sn)
    return Robot.get_xml(sn)


# Robot Configuration data reading APIs
@app.route('/config_down/<sn>', methods=['GET', 'POST', 'PUT', 'DELETE'])
@LoginRequired('-indygo')
def config_down(sn):
    args = form2dict(request.args)
    api_log('config_down', sn, args)
    if request.method == 'GET':
        return Robot.get_config_file(sn)
    if request.json is None:
        req = None
    else:
        req = json.loads(request.json)  # string to dict
    # print(req)
    if request.method == 'POST':
        api_log('SW config upload', request.files['file'].filename)
        return Robot.post_config_file(sn, req, request.files['file'])
    elif request.method == 'PUT':
        pass
    elif request.method == 'DELETE':
        pass
    else:
        return Response("Invalid RESTful APIs...", status=404)


@app.route('/upload_configuration/<sn>', methods=['POST'])
@LoginRequired('-indygo')
def upload_configuration(sn):
    api_log('upload_configuration', sn)
    return Robot.upload_configuration_zip_file(sn)


# Configuraion file download
@app.route('/get_config_down/<robot_id>/<date>', methods=['GET'])
@LoginRequired('-indygo')
def get_config_down(robot_id, date):
    api_log("get_config_down", robot_id, date)
    return Robot.get_config_down(robot_id, date)


# Python Reporter Apis. by cyj 2019-06-24
# mType : 101(num), msg : ip_address, mdata : ip(str)
@app.route('/', methods=['POST'])
@LoginRequired("-indygo")
def update_ip_address():
    return


# mType : 102(num), msg : robot_sn, mdata : serial number(str)
@app.route('/', methods=['POST'])
@LoginRequired("-indygo")
def update_robot_sn_for_mongo():
    return


# mType : 100(num), msg : kpi_config, mdata : KPI string ex) kpi0,temp,hour,mean (str)
@app.route('/report_kpi_string', methods=['POST'])
@LoginRequired("-indygo")
def update_kpi_for_mongo():
    api_log('update_kpi_for_mongo', request.json)
    return Reporter.add_kpi_string_to_admin(current_user.id, json.loads(request.json))


# mType : 200(num), msg : indy_sw_ver, mdata : indySw ver ex) 2.3.0-alpha-scm (str)
@app.route('/repot_indySW_ver', methods=['POST'])
@LoginRequired("-indygo")
def update_indy_sw_ver():
    api_log('update_indy_sw_ver', request.json)
    return Reporter.upload_indy_sw_ver_to_redis(current_user.id, json.loads(request.json))


# mType : 1 mean(num), msg : kpi number ex) kpi0, mdata : Dynamic value ver ex) 56.2321 (str)
@app.route('/', methods=['POST'])
@LoginRequired("-indygo")
def unkown():
    return


# mType : 2 count(num), msg : kpi number ex) kpi0, mdata : Static value ver ex) 1 (str)
@app.route('/', methods=['POST'])
@LoginRequired("-indygo")
def unkown2():
    return


# todo : New DataTable Lib Apis
@app.route('/get_user_list', methods=['GET'])
def get_user_table():
    c = cursor2jsgrid(users.find({}))
    print("User Table : ", c)
    return jsonify(c)


@app.route('/get_company_list', methods=['GET'])
def get_customers_table():
    c = cursor2jsgrid(customers.find({}))
    for i in range(len(c)):
        c[i]['sites'] = '<a href=/companyList/%s>Sites</a>' % str(c[i]['_id'])
    print("Customers Table: ", c)

    'For Example'
    c2 = [
            {
                'a': 1,
                'b': 1,
                'c': 1,
                'd': 1,
                'e': 1,
                'f': 2
            }
        ]

    return jsonify(c)


@app.route('/get_site_list/<companyId>', methods=['GET'])
def get_sites_table(companyId):
    s = cursor2jsgrid(sites.find({"owner_id": objectid.ObjectId(companyId)}))
    for i in range(len(s)):
        s[i]['robots'] = '<a href=/companyList/%s/siteList/%s>Robots</a>' % (str(s[i]['owner_id']), str(s[i]['_id']))
    print("Sites Table ", s)
    return jsonify(s)


@app.route('/get_robot_list/<companyId>/<siteId>', methods=['GET'])
def get_robots_table(companyId, siteId):
    query = {'owner_id': objectid.ObjectId(companyId)}
    if siteId:
        query['site_id'] = objectid.ObjectId(siteId)
    r = cursor2jsgrid(robots.find(query, {'sw_configuration': False}))
    print("Robots Table ", r)
    for i in r:
        # print(i)
        if 'sn' in i:
            # todo : Please Change the path
            state = 'Connected' if Robot.is_connected(i['sn']) else 'Not Connected'
            if state == 'Connected':
                i['connection'] = '<div class="status-pill green" data-title="Complete" data-toggle="tooltip" data-original-title="" title=""></div> %s' % state
            else:
                i['connection'] = '<div class="status-pill yellow" data-title="Complete" data-toggle="tooltip" data-original-title="" title=""></div> %s' % state
            sub_state_dic = Robot.get_status(i['sn'])
            print("State Dic", sub_state_dic, type(sub_state_dic))
            if 'collision' in sub_state_dic and 'error' in sub_state_dic and 'emergency' in sub_state_dic:
                if sub_state_dic['collision'] == 1:
                    i[
                        'connection'] = '<div class="status-pill red" data-title="Complete" data-toggle="tooltip" data-original-title="" title=""></div> %s' % 'Collision'
                elif sub_state_dic['error'] == 1:
                    i[
                        'connection'] = '<div class="status-pill red" data-title="Complete" data-toggle="tooltip" data-original-title="" title=""></div> %s' % 'Error'
                elif sub_state_dic['emergency'] == 1:
                    i[
                        'connection'] = '<div class="status-pill red" data-title="Complete" data-toggle="tooltip" data-original-title="" title=""></div> %s' % 'Emergency'
                else:
                    pass
            i['detail'] = '<a href=/robotList/%s/%s/%s>Robot Information</a>' % (str(i['owner_id']), str(i['site_id']), str(i['sn']))
    return jsonify(r)


@app.route('/get_robot_list', methods=['GET'])
def get_all_robots_table():
    r = cursor2jsgrid(robots.find({}, {'sw_configuration': False}))
    print("Robots Table", r)
    for i in r:
        if 'sn' in i:
            state = 'Connected' if Robot.is_connected(i['sn']) else 'Not Connected'
            if state == 'Connected':
                i['connection'] = '<div class="status-pill green" data-title="Complete" data-toggle="tooltip" data-original-title="" title=""></div> %s' % state
            else:
                i['connection'] = '<div class="status-pill yellow" data-title="Complete" data-toggle="tooltip" data-original-title="" title=""></div> %s' % state
            sub_state_dic = Robot.get_status(i['sn'])
            if 'collision' in sub_state_dic and 'error' in sub_state_dic and 'emergency' in sub_state_dic:
                if sub_state_dic['collision'] == 1:
                    i[
                        'connection'] = '<div class="status-pill red" data-title="Complete" data-toggle="tooltip" data-original-title="" title=""></div> %s' % 'Collision'
                elif sub_state_dic['error'] == 1:
                    i[
                        'connection'] = '<div class="status-pill red" data-title="Complete" data-toggle="tooltip" data-original-title="" title=""></div> %s' % 'Error'
                elif sub_state_dic['emergency'] == 1:
                    i[
                        'connection'] = '<div class="status-pill red" data-title="Complete" data-toggle="tooltip" data-original-title="" title=""></div> %s' % 'Emergency'
                else:
                    pass
            i['detail'] = '<a href=/robotList/%s/%s/%s>Robot Information</a>' % (str(i['owner_id']), str(i['site_id']), str(i['sn']))
    return jsonify(r)


@app.route('/get_robot_list/<companyId>', methods=['GET'])
def get_maint_robots_table(companyId):
    r = cursor2jsgrid(robots.find({'owner_id': objectid.ObjectId(companyId)}, {'sw_configuration': False}))
    print("Robots Table", r)
    for i in r:
        if 'sn' in i:
            state = 'Connected' if Robot.is_connected(i['sn']) else 'Not Connected'
            # 촬영용 더미 데이터
            # if i['sn'] == 'D11929I07009' or i['sn'] == 'D11929I07012':
            #     i['connection'] = '<div class="status-pill yellow" data-title="Complete" data-toggle="tooltip" data-original-title="" title=""></div> Not Connected'
            # else:
            #     i['connection'] = '<div class="status-pill green" data-title="Complete" data-toggle="tooltip" data-original-title="" title=""></div> Connected'
            if state == 'Connected':
                i['connection'] = '<div class="status-pill green" data-title="Complete" data-toggle="tooltip" data-original-title="" title=""></div> %s' % state
            else:
                i['connection'] = '<div class="status-pill yellow" data-title="Complete" data-toggle="tooltip" data-original-title="" title=""></div> %s' % state

            sub_state_dic = Robot.get_status(i['sn'])
            if 'collision' in sub_state_dic and 'error' in sub_state_dic and 'emergency' in sub_state_dic:
                if sub_state_dic['collision'] == 1: i['connection'] = '<div class="status-pill red" data-title="Complete" data-toggle="tooltip" data-original-title="" title=""></div> %s' % 'Collision'
                elif sub_state_dic['error'] == 1: i['connection'] = '<div class="status-pill red" data-title="Complete" data-toggle="tooltip" data-original-title="" title=""></div> %s' % 'Error'
                elif sub_state_dic['emergency'] == 1: i['connection'] = '<div class="status-pill red" data-title="Complete" data-toggle="tooltip" data-original-title="" title=""></div> %s' % 'Emergency'
                else: pass
            i['detail'] = '<a href=/robotList/%s/%s/%s>Robot Information</a>' % (str(i['owner_id']), str(i['site_id']), str(i['sn']))
    return jsonify(r)


@app.route("/user_register", methods=['POST'])
def add_user():
    user_email = request.form['email']
    user_phone = request.form['phone']
    user_name = request.form['username']
    user_pwd = request.form['password']
    user_company = request.form['company']
    user_etc = request.form['etc']
    user_add_time = str(utc.localize(datetime.utcnow()).astimezone(KST).strftime(fmt))

    h = hashlib.sha1(user_pwd.encode('utf-8'))  # todo : this is sha1 HASH object.
    print(h)

    def permit_map(permission):
        map = {
            'Admin': 'admin',
            'Developer': 'developer',
            'Maintainer': 'maintainer',
            None: None
        }
        return map[permission]

    user_permission = permit_map(request.form['permission'])

    if users.find_one({'email': user_email}) is not None: return Response("Invalid email", status=404)
    users.insert_one({'name': user_name, 'password': h.hexdigest(), 'permission': user_permission, 'company': user_company
                      , 'phone': user_phone, 'email': user_email, 'etc': user_etc, 'add_time': user_add_time})
    print("Success added email : %s" % user_email)
    return redirect(url_for('admin_user_register'))


@app.route("/company_register", methods=['POST'])
def company_register():
    company_name = request.form['companyName']
    company_head = request.form['companyHead']
    company_manager_name = request.form['managerName']
    company_info = request.form['info']
    company_add_time = str(utc.localize(datetime.utcnow()).astimezone(KST).strftime(fmt))
    company_etc = request.form['etc']

    if customers.find_one({'name': company_name}) is not None: return Response("Invalid name", status=404)
    customers.insert_one({'name': company_name, 'location': company_head, 'header': company_manager_name,
                      'info': company_info, 'add_time': company_add_time, 'etc': company_etc})
    print("Success added company : %s" % company_name)
    return redirect(url_for('admin_customer_register'))


@app.route("/kpiInit", methods=['POST'])
def kpiInit():
    return Reporter.kpi_init(json.loads(request.json))


@app.route("/undefined_post", methods=['POST'])
def undefinedPost():
    return print(json.loads(request.json))


@app.route("/getTimeSeriesDatabaseDataTest", methods=['GET'])
def getTimeSeriesDatabaseDataTest():
    print("Influx Ping : ", rtdb.ping())
    print("Now TimeStamp: ", datetime.now().timestamp())
    _str = 'SELECT mean("joint0") AS "mean_joint0" FROM "D11929I07003" WHERE time > now() - 1h GROUP BY time(10s) FILL(linear)'
    data = list(rtdb.query(_str, epoch='s'))
    if len(data) > 0:
        for i in data[0]:
            timestamp2datetime = datetime.fromtimestamp(i['time'], KST)
            i['time'] = timestamp2datetime.strftime(fmtAll)
    else:
        data[0] = ''
    # print("After Influx Data : ", data)
    # print("Filtering Data : ", list(data.get_points(measurement='D11929I07003')))
    return json.dumps(data[0], ensure_ascii=False).encode('utf8')


@app.route("/getTimeSeriesDatabaseData/<sn>/<key>/recent/<unit>/<aggregation>/<axis>", methods=['GET'])
def getTimeSeriesDatabaseData(sn, key, unit, reguarize=None, aggregation='mean', axis='1'):
    print("Influx Ping : ", rtdb.ping())
    print("Now TimeStamp: ", datetime.now().timestamp())
    if reguarize is None:
        if aggregation == 'mean' and axis == '6':
            _qry = 'mean("joint0"), mean("joint1"), mean("joint2"), mean("joint3"), mean("joint4"), mean("joint5")'
            data = list(rtdb.query('select %s from \"%s\" where time > now() - 1h group by time(10s) fill(linear)' % (
                _qry, 'D11929I07003'), epoch='s'))
        else:
            data = list(rtdb.query('select %s(%s) from \"%s\" where time > now() - 1h group by time(600s) fill(linear)' % (
                aggregation, key, 'D11929I07003'), epoch='s'))
    else:
        data = list(rtdb.query('select mean(%s) from \"%s\" where time > now() - 5m and time < now() group by time(10s) fill(linear)' % (
            key, 'D11929I07003'), epoch='s'))

    if len(data) > 0:
        for i in data[0]:
            timestamp2datetime = datetime.fromtimestamp(i['time'], KST)
            i['time'] = timestamp2datetime.strftime(fmtAll)
            if not aggregation == 'mean' and not axis == '1': continue
            if aggregation == 'mean' and axis == '1' and not i['mean'] == False:
                i['mean'] = round(i['mean'], 0)
    else:
        data[0] = ''
    # print("After Influx Data : ", data)
    # print("Filtering Data : ", list(data.get_points(measurement='D11929I07003')))
    return json.dumps(data[0], ensure_ascii=False).encode('utf8')





